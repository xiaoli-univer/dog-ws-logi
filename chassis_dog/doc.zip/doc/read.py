import pickle
import pprint
import time
from datetime import date

import matplotlib.pyplot as plt

plt.style.use("seaborn-poster")


def figure(fn="22_17_02"):
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "vel_" + fn + ".pkl", "rb"
    ) as f:
        vel = pickle.load(f)
        # pprint.pprint(vel)
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "force_" + fn + ".pkl", "rb"
    ) as f:
        force = pickle.load(f)
        # pprint.pprint(force)
    # print(vel[:117] + vel[170:])

    for i, v in enumerate(vel):
        vel[i] = v * 10

    x_index = range(len(vel))
    plt.clf()
    plt.plot(x_index, vel, ".-", label="vel value")
    plt.plot(x_index, force, ".-", label="press value")
    plt.title("sensor reading")
    plt.xlabel("T")
    plt.ylabel("results")
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True)
    # plt.ylim((-20, 20))
    plt.ioff()
    # plt.pause(0.1)
    plt.show()


def figuresim(fn="22_17_02"):
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "vel_sim_" + fn + ".pkl", "rb"
    ) as f:
        vel = pickle.load(f)
        # pprint.pprint(vel)
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "force_sim_" + fn + ".pkl", "rb"
    ) as f:
        force = pickle.load(f)
        # pprint.pprint(force)
    # print(vel[:117] + vel[170:])

    for i, v in enumerate(vel):
        vel[i] = v * 10

    x_index = range(len(vel))
    plt.clf()
    plt.plot(x_index, vel, ".-", label="vel value")
    plt.plot(x_index, force, ".-", label="press value")
    plt.title("sensor reading")
    plt.xlabel("T")
    plt.ylabel("results")
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True)
    # plt.ylim((-20, 20))
    plt.ioff()
    # plt.pause(0.1)
    plt.show()


def figurecom():
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "vel_22_16_44.pkl", "rb"
    ) as f:
        velt = pickle.load(f)
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "force_22_16_44.pkl", "rb"
    ) as f:
        forcet = pickle.load(f)
    with open(
        r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + "force_sim_22_17_02.pkl", "rb"
    ) as f:
        forcesim = pickle.load(f)
    # for i, v in enumerate(vel):
    #     vel[i] = v * 10
    vel1 = velt[240:350]
    force1 = forcet[240:350]
    force2 = forcesim[20:130]

    x_index = range(len(vel1))
    fig = plt.figure()
    ax = plt.subplot(211)
    av1 = sum(vel1) / len(vel1)
    print(av1)
    s = 0
    for i, v in enumerate(vel1):
        if v > 0.3:
            s += 1
    print(1 - s / len(vel1), len(vel1))
    plt.plot(x_index, vel1, label="$\\dot{x_r}$")
    plt.plot(x_index, [0.3] * len(vel1), label="$\\dot{x_d}$")
    # plt.plot(vel1, force1)

    ax2 = plt.subplot(212)
    av1 = sum(force1) / len(force1)
    av2 = sum(force2) / len(force2)
    df = []
    for i in range(len(force1) - 1):
        df.append(force1[i] - force2[i])
    print(av1, av2, sum(df) / len(df))
    plt.plot(x_index, force1, label="$F_{e1}$", color="cornflowerblue")
    plt.plot(x_index, force2, label="$F_{e2}}$", color="yellowgreen")
    plt.plot(
        x_index,
        [av1] * len(force1),
        color="cornflowerblue",
        linestyle="--",
        label="$\\overline{F}_{e1}$",
    )
    plt.plot(
        x_index,
        [av2] * len(force2),
        color="yellowgreen",
        linestyle="--",
        label="$\\overline{F}_{e2}$",
    )
    ax.set_ylabel("velocity(m/s)", fontsize=25)
    ax.legend(fontsize=23, loc="lower right")  # 设置图表图例在左上角
    ax.grid(True, alpha=0.2)  # 绘制网格dodgerblue
    ax2.set_ylabel("$Force(N)$", fontsize=25)
    ax2.legend(fontsize=23, loc="lower right")  # 设置图表图例在左上角
    ax2.grid(True, alpha=0.2)  # 绘制网格
    ax.tick_params(axis="both", labelsize=23)
    ax2.tick_params(axis="both", labelsize=23)
    plt.xlabel("Time(s)", fontsize=25)
    # plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0.2, wspace=0.2)
    # plt.margins(0, 0)
    # plt.savefig(r"C:\Users\Nianf\OneDrive\文档\exp1.pdf")
    plt.show()
    # plt.clf()
    # plt.subplot(211)
    # plt.plot(x_index, vel1, label="vel")
    # plt.plot(x_index, [0.3] * len(vel1),  label="vel")
    # plt.subplot(212)
    # plt.plot(x_index, force1,  label="force")
    # plt.plot(x_index, force2,  label="force without control")
    # plt.title("sensor reading")
    # plt.xlabel("T")
    # plt.ylabel("results")
    # plt.xticks(rotation=45)
    # plt.legend()
    # plt.grid(True)
    # # plt.ylim((-20, 20))
    # plt.ioff()
    # # plt.pause(0.1)
    # plt.show()


if __name__ == "__main__":
    figurecom()
    # figuresim("22_17_02")  # no control 0.3 x=:150
    # figure("22_16_44")  # 0.3 x=200:
    # figure("22_16_50")  # 0.5

    exit()
    # fn = "vel_22_15_14.pkl"
    # fn2 = "force_22_15_14.pkl"
    fn = "vel_sim_22_17_02.pkl"
    fn2 = "force_sim_22_17_02.pkl"
    # fn2="force"+time.strftime("_%d_%H_%M", time.localtime())+".pkl"

    with open(r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + fn, "rb") as f:
        vel = pickle.load(f)
        pprint.pprint(vel)
    with open(r"E:\root_ws\dos_ws\src\chassis_dog\doc/" + fn2, "rb") as f:
        force = pickle.load(f)
        pprint.pprint(force)
    print(vel[:117] + vel[170:])

    for i, v in enumerate(vel):
        vel[i] = v * 10

    x_index = range(vel)
    plt.clf()
    plt.plot(x_index, vel, ".-", label="vel value")
    plt.plot(x_index, force, ".-", label="press value")
    plt.title("sensor reading")
    plt.xlabel("T")
    plt.ylabel("results")
    plt.xticks(rotation=45)
    plt.legend()
    plt.grid(True)
    # plt.ylim((-20, 20))
    plt.ioff()
    # plt.pause(0.1)
    plt.show()
    p = [
        0.0022749107445179106,
        0.0022749107445179106,
        0.0022749107445179106,
        0.0022749107445179106,
        0.0030795734969473187,
        0.003168980469439475,
        0.003168980469439475,
        0.003705422304392414,
        0.00406305019436104,
        0.00406305019436104,
        0.00406305019436104,
        0.0034372013869159446,
        0.003973643221868883,
        0.00406305019436104,
        0.00406305019436104,
        0.00406305019436104,
        0.004152457166853196,
        0.004957119919282604,
        0.004957119919282604,
        0.004957119919282604,
        0.004957119919282604,
        0.004957119919282604,
        0.004688899001806135,
        0.05949537313949804,
        -0.038941703574366215,
        0.1411239390248369,
        0.03222624652939032,
        0.04063050194365303,
        -0.0004967054027389395,
        0.052342815340125526,
        0.0020960967995335977,
        0.15721719407342505,
        0.3975431361323416,
        0.3049175126304675,
        0.7085005864600618,
        0.8084575817062927,
        -0.2823074826980161,
        -1.3454457926022485,
        15.77623977916875,
        12.77623977916875,
        1.0639827090888758,
        0.9055535538327746,
        0.14675657829184274,
        0.051627559560188274,
        -0.052352749448189684,
        -0.1385410709306285,
        -0.34891567720467265,
        -0.6251832222054361,
        -0.679989696343128,
        -0.7224580082769023,
        -0.7287164963513533,
        -0.685711742582626,
        -0.6945630328593495,
        -0.6706019642314516,
        -0.6681879759741634,
        -0.6620188948722046,
        -0.6542404882653869,
        -0.6590684647799634,
        -0.6416341051439929,
        -0.582267875409201,
        -0.2530714026930809,
        -0.2962549704067925,
        -0.6007751187150774,
        -0.8539756648128645,
        -3.459652471124272,
        -1.9484064150893516,
        -0.7006427069888161,
        -0.48114858952057205,
        -0.009169181734478116,
        0.24671357353807366,
        0.293205199233995,
        -0.4253586386854664,
        -4.539241663967061,
        -7.131149796514698,
        -5.224724922064446,
        -2.634247301076684,
        -0.7407864376377944,
        0.27612846748799313,
        0.06557504726896468,
        -2.974977273244292,
        -5.791833348582195,
        -5.948474364388453,
        -4.579027766726092,
        -3.06071855986427,
        -1.8604299541570697,
        -1.8186768980032326,
        -1.4482638109682284,
        -2.6860139381496424,
        -3.4049354039590725,
        -2.9848120402184293,
        -3.5014949342506014,
        -4.751851444553431,
        -6.8952047961078975,
        -10.576089853609979,
        -11.485090542937755,
        -12.306472399223196,
        -9.15612831648955,
        -5.549540453128451,
        -3.1941137628225675,
        -3.6170981496829597,
        -7.481088686848999,
        -12.185236544523832,
        -14.513483515192078,
        -12.584706897618787,
        -7.754852836619982,
        -3.2471320975104163,
        -1.6379854065965844,
        -2.5219521436265353,
        -5.31815520831875,
        -9.079148913173803,
        -8.457859861325808,
        -3.1439564512544678,
        0.3084043845576616,
        14.44623059707268,
        0.3844003111759946,
        -2.5940141634552134,
        -6.477942455487003,
        -6.205608817275895,
        -3.4232638333199645,
        -1.7395517273476742,
        -1.2804469236004508,
        -0.9899636699734344,
        -1.4642676590443244,
        -3.455539750389633,
        -8.233001325508035,
        -10.141393153353114,
        -10.556330912689212,
        -9.398152991025817,
        -6.620457169639501,
        -4.476746190195044,
        -2.2312900760545347,
        -1.2361904722168333,
        -1.073201561363632,
        -1.47776811189064,
        -1.4997622271237105,
        -2.1271309531011724,
        -2.233078215504378,
        -1.52461736547653,
        -1.49144737868194,
        -1.1563500457813376,
        -1.7306110300984585,
        -0.48812233337496025,
        -0.061651074587373955,
        -0.046809517153675984,
        -1.014818808326254,
        -2.1745166485220153,
        -1.2166997522135432,
        -0.3652771531707373,
        -1.100023653111279,
        -0.7170935899273729,
        -1.5832683394313847,
        -1.5832683394313847,
        14.384092751190632,
        0.536034536522692,
        0.2821187346449676,
        0.2546707940898756,
        0.06128351258934117,
        -0.21811327644864775,
        -0.2568264955377515,
        -0.4012187561125842,
        -0.25199851902317505,
        0.038752955521317745,
        0.28310221134238134,
        0.1919965063728739,
        0.027130049097337405,
        0.03607074634655305,
        0.08926789497938614,
        0.1261035676461546,
        0.11448066122217426,
        0.09051959259427633,
        0.08676449974960576,
        0.202904157016917,
        0.19575159921754448,
        -0.36572418803319806,
        -0.22186836929331832,
        -0.1184245021198933,
        -0.5209346922795817,
        -0.7965763884729,
        -0.6392201168867047,
        -0.5947848515581029,
        -0.6001492699076323,
        -0.48856936823742103,
        -0.6930431143269828,
        -0.45486293960787805,
        -0.5825360963266775,
        -0.36044917665616083,
        -0.3728767458325706,
        -0.7370313447931238,
        -1.1972984391827453,
        -1.4620324847320205,
        -1.8025836429546445,
        -0.6236633036730694,
        0.10562937094545077,
        0.27675431629543823,
        0.3505150686014673,
        0.2725521885883069,
        0.3308455346531929,
        0.3345112205253713,
        0.32557052327615565,
        0.30295055923564007,
        0.331471383460638,
        0.3161827911644792,
        0.2897183273068009,
        0.3310243485981772,
        0.3528396498862634,
        0.26888650271612846,
        0.24564068986816778,
        0.2306203184894855,
        0.23687880656393645,
        0.23026269059951687,
        0.23026269059951687,
        0.23026269059951687,
        0.23026269059951687,
    ]
